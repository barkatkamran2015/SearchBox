<?php

?>

<!DOCTYPE html>
<html>
<head>
	<title>Search Box</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

	<h1>Search Box</h1>

	<div class="box">
		<i class="fa fa-search" aria-hidden="true"></i>

		<input type="text" name="search_text" id="search_text" placeholder="Search Box..." class="form-control" />
		<div id="result"></div>
	</div>

</body>
</html>

<script>
	$(document).ready(function(){
		load_data();
		function load_data(query){
			$.ajax({
				url:"",
				method: "post",
				data: {query:query},
				success: function(data){
					$('#result').html(data);
				}
			});
		}
		$('#search_text').keyup(function(){
			var search = $(this).val();
			if(search != ''){
				load_data(search);
			}
			else{
				load_data();
			}
		});
	});
</script>