<?php
$connect = mysqli_connect("localhost", "root","customer_table");
$output = '';
if(isset($_POST["query"]))
{
	$search = mysqli_real_escape_string($connect, $_POST["query"]);
	$query = "
	SELECT * from users where CustomerName Like '%".$search."%'
	OR Address Like '%".$search."%'
	OR City Like '%".$search."%'
	OR Postalcode Like '%".$search."%'
	OR Country Like '%".$search. "%'
	";
	}
	else{
	$query = "
	select * from users ORDER BY CustomerID";
	}
	$result = mysqli_query($conect, $query);
	if(mysqli_num_rows($result) > 0){
	$output .='<div clas = "table-responsible">
	<tr>
	<th>Customer Name</th>
	<th>Address</th>
	<th>City</th>
	<th>Postalcode</th>
	<th>Country</th>
	';
	while($rows = mysqli_fetch_array($result)){
	$output .='
	<tr>
	<td>'.$rows["CustomerName"]. '</td>
	<td>'.$rows["Address"]. '</td>
	<td>'.$rows["City"]. '</td>
	<td>'.$rows["Postalcode"]. '</td>
	<td>'.$rows["Country"]. '</td>
	</tr>
	';
	}
	echo $output;
	}
	else{
	echo 'Data not found';
	}
	?>